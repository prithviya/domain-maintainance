<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/layout.php';

$pdo = db();

function redirectClients(string $message = '', string $type = 'success'): void
{
    $query = [];
    if ($message !== '') {
        $query['toast'] = $message;
        $query['toast_type'] = $type;
    }
    $url = 'clients.php';
    if ($query) {
        $url .= '?' . http_build_query($query);
    }
    header('Location: ' . $url);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save_client') {
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        $name = trim((string) ($_POST['name'] ?? ''));
        $company = trim((string) ($_POST['company'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $phone = trim((string) ($_POST['phone'] ?? ''));
        $renewalDate = trim((string) ($_POST['renewal_date'] ?? ''));
        $status = ($_POST['status'] ?? 'Active') === 'Disabled' ? 'Disabled' : 'Active';

        if ($name !== '' && $phone !== '') {
            if ($id > 0) {
                $stmt = $pdo->prepare('UPDATE clients SET name = ?, company = ?, email = ?, phone = ?, renewal_date = ?, status = ? WHERE id = ? AND deleted_at IS NULL');
                $stmt->execute([$name, $company, $email, $phone, $renewalDate ?: null, $status, $id]);
                redirectClients('Client updated successfully');
            } else {
                $stmt = $pdo->prepare('INSERT INTO clients (name, company, email, phone, renewal_date, status) VALUES (?, ?, ?, ?, ?, ?)');
                $stmt->execute([$name, $company, $email, $phone, $renewalDate ?: null, $status]);
                redirectClients('Client added successfully');
            }
        }
        redirectClients('Client name and phone are required', 'error');
    }

   if ($action === 'add_service') {
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $serviceEntries = $_POST['services'] ?? [];
        $insertedCount = 0;
    
        if ($clientId > 0) {
            $stmt = $pdo->prepare(
                'INSERT INTO services 
                (client_id, service_type, name, renewal_date, amount, ownership_type, comment)
                VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
    
            foreach ($serviceEntries as $entry) {
                $name = trim((string) ($entry['name'] ?? ''));
                $renewalDate = trim((string) ($entry['renewal_date'] ?? ''));
                $amount = (float) ($entry['amount'] ?? 0);
                $ownershipType = ($entry['ownership_type'] ?? 'client') === 'our' ? 'our' : 'client';
                $comment = trim((string) ($entry['comment'] ?? ''));
    
                $types = $entry['types'] ?? [];
    
                if ($name === '' || empty($types)) {
                    continue;
                }
    
                foreach ($types as $type) {
                    if (!in_array($type, ['domain', 'hosting'])) continue;
    
                    $stmt->execute([
                        $clientId,
                        $type,
                        $name,
                        $renewalDate ?: null,
                        $amount,
                        $ownershipType,
                        $comment ?: null
                    ]);
    
                    $insertedCount++;
                }
            }
        }
    
        if ($insertedCount > 0) {
            redirectClients('Service added successfully');
        }
    
        redirectClients('Service name and type required', 'error');
    }

    $serviceId = (int) ($_POST['service_id'] ?? 0);
    $serviceType = ($_POST['service_type'] ?? 'domain') === 'hosting' ? 'hosting' : 'domain';
    $name = trim((string) ($_POST['name'] ?? ''));
    $renewalDate = trim((string) ($_POST['renewal_date'] ?? ''));
    $amount = (float) ($_POST['amount'] ?? 0);
    $ownershipType = ($_POST['ownership_type'] ?? 'client') === 'our' ? 'our' : 'client';
    $comment = trim((string) ($_POST['comment'] ?? ''));

    if ($serviceId > 0 && $name !== '') {
        $stmt = $pdo->prepare(
            'UPDATE services
             SET service_type=?, name=?, renewal_date=?, amount=?, ownership_type=?, comment=?
             WHERE id=? AND deleted_at IS NULL'
        );

        $stmt->execute([
            $serviceType,
            $name,
            $renewalDate ?: null,
            $amount,
            $ownershipType,
            $comment ?: null,
            $serviceId
        ]);

        redirectClients('Service updated successfully');
    }

    redirectClients('Service name required', 'error');
}
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE clients SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL');
        $stmt->execute([$id]);
        $stmt = $pdo->prepare('UPDATE services SET deleted_at = NOW() WHERE client_id = ? AND deleted_at IS NULL');
        $stmt->execute([$id]);
        $stmt = $pdo->prepare('UPDATE billings SET deleted_at = NOW() WHERE client_id = ? AND deleted_at IS NULL');
        $stmt->execute([$id]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    redirectClients('Client deleted successfully');
}

if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    $stmt = $pdo->prepare("UPDATE clients SET status = CASE WHEN status = 'Active' THEN 'Disabled' ELSE 'Active' END WHERE id = ? AND deleted_at IS NULL");
    $stmt->execute([$id]);
    redirectClients('Client status updated');
}

if (isset($_GET['delete_service'])) {
    $id = (int) $_GET['delete_service'];
    $stmt = $pdo->prepare('UPDATE services SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL');
    $stmt->execute([$id]);
    redirectClients('Service deleted successfully');
}

$clientPerPage = 25;
$clientPage = max(1, (int) ($_GET['client_page'] ?? 1));
$filterClientName = trim((string) ($_GET['filter_client_name'] ?? ''));
$filterServiceType = (string) ($_GET['filter_service_type'] ?? '');
$filterRenewalMonth = trim((string) ($_GET['filter_renewal_month'] ?? ''));

if (!in_array($filterServiceType, ['', 'domain', 'hosting'], true)) {
    $filterServiceType = '';
}
if ($filterRenewalMonth !== '' && !preg_match('/^\d{4}-\d{2}$/', $filterRenewalMonth)) {
    $filterRenewalMonth = '';
}

$clientWhere = ['c.deleted_at IS NULL'];
$clientParams = [];

if ($filterClientName !== '') {
    $clientWhere[] = '(c.name LIKE :client_name_1 OR c.company LIKE :client_name_2)';
    $clientParams[':client_name_1'] = '%' . $filterClientName . '%';
    $clientParams[':client_name_2'] = '%' . $filterClientName . '%';
}
if ($filterServiceType !== '') {
    $clientWhere[] = 'EXISTS (
        SELECT 1 FROM services s1
        WHERE s1.client_id = c.id
          AND s1.deleted_at IS NULL
          AND s1.service_type = :service_type
    )';
    $clientParams[':service_type'] = $filterServiceType;
}
if ($filterRenewalMonth !== '') {
    $clientWhere[] = 'EXISTS (
        SELECT 1 FROM services s2
        WHERE s2.client_id = c.id
          AND s2.deleted_at IS NULL
          AND DATE_FORMAT(s2.renewal_date, "%Y-%m") = :renewal_month
    )';
    $clientParams[':renewal_month'] = $filterRenewalMonth;
}

$clientWhereSql = implode(' AND ', $clientWhere);

$clientCountStmt = $pdo->prepare("SELECT COUNT(*) FROM clients c WHERE {$clientWhereSql}");
foreach ($clientParams as $key => $value) {
    $clientCountStmt->bindValue($key, $value);
}
$clientCountStmt->execute();
$clientTotal = (int) $clientCountStmt->fetchColumn();

$clientTotalPages = max(1, (int) ceil($clientTotal / $clientPerPage));
if ($clientPage > $clientTotalPages) {
    $clientPage = $clientTotalPages;
}
$clientOffset = ($clientPage - 1) * $clientPerPage;

$clientStmt = $pdo->prepare("SELECT c.* FROM clients c WHERE {$clientWhereSql} ORDER BY c.id DESC LIMIT :limit OFFSET :offset");
foreach ($clientParams as $key => $value) {
    $clientStmt->bindValue($key, $value);
}
$clientStmt->bindValue(':limit', $clientPerPage, PDO::PARAM_INT);
$clientStmt->bindValue(':offset', $clientOffset, PDO::PARAM_INT);
$clientStmt->execute();
$clients = $clientStmt->fetchAll(PDO::FETCH_ASSOC);

$serviceStmt = $pdo->prepare('SELECT * FROM services WHERE client_id = ? AND deleted_at IS NULL ORDER BY id DESC');

renderLayoutStart('Clients Management', 'clients');
?>

<div class="card" style="margin-bottom: 20px;">
    <div class="row-head">
        <h3><i class="fas fa-user-edit"></i> Add New Client</h3>
    </div>
    <form method="post">
        <input type="hidden" name="action" value="save_client">
        <input type="hidden" name="id" value="0">
        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:10px;">
            <div class="form-group" style="flex:1; min-width:220px;"><label>Client Name</label><input type="text" name="name" required value=""></div>
            <div class="form-group" style="flex:1; min-width:220px;"><label>Company</label><input type="text" name="company" value=""></div>
            <div class="form-group" style="flex:1; min-width:220px;"><label>Email</label><input type="email" name="email" value=""></div>
        </div>
        <div style="display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap;">
            <div class="form-group" style="flex:1; min-width:220px;"><label>Phone *</label><input type="text" name="phone" required value=""></div>
            <div class="form-group" style="flex:1; min-width:180px;"><label>Renewal Date</label><input type="date" name="renewal_date" value=""></div>
            <div class="form-group" style="width:180px;">
                <label>Status</label>
                <select name="status">
                    <option value="Active" selected>Active</option>
                    <option value="Disabled">Disabled</option>
                </select>
            </div>
            <div style="display:flex; gap:8px; padding-bottom:2px;">
                <button class="btn-primary" type="submit"><i class="fas fa-save"></i> Save Client</button>
                <a class="btn-secondary" href="clients.php">Clear</a>
            </div>
        </div>
    </form>
</div>

<div class="card table-wrap">
    <div class="row-head">
        <h3><i class="fas fa-users"></i> Client List</h3>
    </div>
    <form method="get" style="margin-bottom:16px;">
        <div style="display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap;">
            <div class="form-group" style="flex:1; min-width:220px;">
                <label>Client Name</label>
                <input type="text" name="filter_client_name" value="<?= esc($filterClientName) ?>" placeholder="Search by name/company">
            </div>
            <div class="form-group" style="flex:1; min-width:180px;">
                <label>Service Based</label>
                <select name="filter_service_type">
                    <option value="">All Services</option>
                    <option value="domain" <?= $filterServiceType === 'domain' ? 'selected' : '' ?>>Domain</option>
                    <option value="hosting" <?= $filterServiceType === 'hosting' ? 'selected' : '' ?>>Hosting</option>
                </select>
            </div>
            <div class="form-group" style="flex:1; min-width:180px;">
                <label>Renewal (Month)</label>
                <input type="month" name="filter_renewal_month" value="<?= esc($filterRenewalMonth) ?>">
            </div>
            <div style="display:flex; gap:8px; padding-bottom:2px;">
                <button class="btn-primary" type="submit"><i class="fas fa-filter"></i> Apply Filter</button>
                <a class="btn-secondary" href="clients.php">Reset</a>
            </div>
        </div>
    </form>
    <table class="data-table">
        <thead>
            <tr>
                <th>Client</th>
                <th>Contact</th>
                <th>Services</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$clients): ?>
                <tr><td colspan="5" class="inline-muted">No clients found.</td></tr>
            <?php else: ?>
                <?php foreach ($clients as $client): ?>
                    <?php
                    $serviceStmt->execute([(int) $client['id']]);
                    $services = $serviceStmt->fetchAll(PDO::FETCH_ASSOC);
                    ?>
                    <tr>
                        <td>
                            <strong><?= esc($client['name']) ?></strong><br>
                            <span class="inline-muted"><?= esc($client['company']) ?></span>
                            <?php if (!empty($client['renewal_date'])): ?>
                                <br><small class="inline-muted">Renewal: <?= formatAppDate($client['renewal_date']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= esc($client['email']) ?><br>
                            <span class="inline-muted"><?= esc($client['phone']) ?></span>
                        </td>
                        <td>
                            <?php if (!$services): ?>
                                <span class="inline-muted">No services</span>
                            <?php else: ?>
                                <?php foreach ($services as $service): ?>
                                    <div class="service-block">
                                        <strong><?= $service['service_type'] === 'domain' ? 'Domain' : 'Hosting' ?></strong>:
                                        <?= esc($service['name']) ?>
                                        <br>
                                         <?= $service['ownership_type'] === 'our' ? 'Our Side' : 'Client' ?>
                                        <div class="action-links">
                                            <button
                                                type="button"
                                                class="icon-action-btn open-service-edit-modal"
                                                title="Edit Service"
                                                data-id="<?= (int) $service['id'] ?>"
                                                data-type="<?= esc($service['service_type']) ?>"
                                                data-name="<?= esc($service['name']) ?>"
                                                data-renewal-date="<?= esc($service['renewal_date']) ?>"
                                                data-amount="<?= esc((string) $service['amount']) ?>"
                                                data-ownership-type="<?= esc($service['ownership_type']) ?>"
                                                data-comment="<?= esc($service['comment'] ?? '') ?>"
                                            ><i class="fas fa-pen"></i></button>
                                            <a class="icon-action icon-danger" title="Delete Service" href="clients.php?delete_service=<?= (int) $service['id'] ?>" onclick="return confirm('Delete this service?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <div class="service-block">
                                <button
                                    type="button"
                                    class="icon-action-btn open-add-service-modal"
                                    title="Add Service"
                                    data-client-id="<?= (int) $client['id'] ?>"
                                    data-client-name="<?= esc($client['name']) ?>"
                                >
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </td>
                        <td><span class="badge <?= $client['status'] === 'Active' ? 'badge-active' : 'badge-expiring' ?>"><?= esc($client['status']) ?></span></td>
                        <td>
                            <div class="action-links">
                                <button
                                    type="button"
                                    class="icon-action-btn open-edit-modal"
                                    title="Edit Client"
                                    data-id="<?= (int) $client['id'] ?>"
                                    data-name="<?= esc($client['name']) ?>"
                                    data-company="<?= esc($client['company']) ?>"
                                    data-email="<?= esc($client['email']) ?>"
                                    data-phone="<?= esc($client['phone']) ?>"
                                    data-renewal-date="<?= esc($client['renewal_date'] ?? '') ?>"
                                    data-status="<?= esc($client['status']) ?>"
                                ><i class="fas fa-user-pen"></i></button>
                                <a class="icon-action icon-toggle" title="<?= $client['status'] === 'Active' ? 'Disable Client' : 'Enable Client' ?>" href="clients.php?toggle=<?= (int) $client['id'] ?>">
                                    <i class="fas <?= $client['status'] === 'Active' ? 'fa-toggle-off' : 'fa-toggle-on' ?>"></i>
                                </a>
                                <a class="icon-action icon-danger" title="Delete Client" href="clients.php?delete=<?= (int) $client['id'] ?>" onclick="return confirm('Delete client and all services?');">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if ($clientTotalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $clientTotalPages; $i++): ?>
                <?php
                $clientPageQuery = [
                    'client_page' => $i,
                    'filter_client_name' => $filterClientName,
                    'filter_service_type' => $filterServiceType,
                    'filter_renewal_month' => $filterRenewalMonth,
                ];
                foreach ($clientPageQuery as $queryKey => $queryValue) {
                    if ($queryValue === '') {
                        unset($clientPageQuery[$queryKey]);
                    }
                }
                $clientPageLink = 'clients.php?' . http_build_query($clientPageQuery);
                ?>
                <?php if ($i === $clientPage): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="<?= esc($clientPageLink) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>

<div id="addServiceModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:1000; align-items:center; justify-content:center; padding:16px;">
    <div class="card" style="width:100%; max-width:760px; max-height:90vh; overflow:auto;">
        <div class="row-head">
            <h3><i class="fas fa-plus-circle"></i> Add Service for <span id="addServiceClientName"></span></h3>
            <button type="button" class="btn-secondary" id="closeAddServiceModal">Close</button>
        </div>
        <form method="post">
            <input type="hidden" name="action" value="add_service">
            <input type="hidden" name="client_id" id="addServiceClientId" value="">
            <div id="serviceEntryContainer" style="display:flex; flex-direction:column; gap:12px;"></div>
            <div style="margin-top:10px;">
                <button type="button" class="btn-secondary" id="addOtherServiceBtn"><i class="fas fa-plus"></i> Add Other Service</button>
            </div>
            <div style="margin-top: 12px; display: flex; gap: 8px;">
                <button class="btn-primary" type="submit"><i class="fas fa-save"></i> Save Service</button>
            </div>
        </form>
    </div>
</div>

<div id="editClientModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:1000; align-items:center; justify-content:center; padding:16px;">
    <div class="card" style="width:100%; max-width:700px; max-height:90vh; overflow:auto;">
        <div class="row-head">
            <h3><i class="fas fa-user-edit"></i> Edit Client Details</h3>
            <button type="button" class="btn-secondary" id="closeEditModal">Close</button>
        </div>
        <form method="post">
            <input type="hidden" name="action" value="save_client">
            <input type="hidden" name="id" id="editClientId" value="">
            <div class="form-grid">
                <div class="form-group"><label>Client Name *</label><input type="text" name="name" id="editClientName" required></div>
                <div class="form-group"><label>Company</label><input type="text" name="company" id="editClientCompany"></div>
                <div class="form-group"><label>Email *</label><input type="email" name="email" id="editClientEmail"></div>
                <div class="form-group"><label>Phone</label><input type="text" name="phone" id="editClientPhone"></div>
                <div class="form-group"><label>Renewal Date</label><input type="date" name="renewal_date" id="editClientRenewalDate"></div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="editClientStatus">
                        <option value="Active">Active</option>
                        <option value="Disabled">Disabled</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Comment</label>
                    <input type="text" name="comment" id="editServiceComment">
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; gap: 8px;">
                <button class="btn-primary" type="submit"><i class="fas fa-save"></i> Update Client</button>
            </div>
        </form>
    </div>
</div>

<div id="editServiceModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:1000; align-items:center; justify-content:center; padding:16px;">
    <div class="card" style="width:100%; max-width:760px; max-height:90vh; overflow:auto;">
        <div class="row-head">
            <h3><i class="fas fa-cogs"></i> Edit Service</h3>
            <button type="button" class="btn-secondary" id="closeServiceEditModal">Close</button>
        </div>
        <form method="post">
            <input type="hidden" name="action" value="update_service">
            <input type="hidden" name="service_id" id="editServiceId" value="">
            <div class="form-grid">
                <div class="form-group">
                    <label>Service Type</label>
                    <select name="service_type" id="editServiceType" required>
                        <option value="domain">Domain</option>
                        <option value="hosting">Hosting</option>
                    </select>
                </div>
                <div class="form-group"><label>Name / Domain</label><input type="text" name="name" id="editServiceName" required></div>
                <div class="form-group"><label>Last Renewal Date</label><input type="date" name="renewal_date" id="editServiceRenewalDate"></div>
                <div class="form-group"><label>Amount</label><input type="number" step="0.01" name="amount" id="editServiceAmount"></div>
                <div class="form-group">
                    <label>Ownership</label>
                    <select name="ownership_type" id="editServiceOwnershipType">
                        <option value="our">Our Side</option>
                         <option value="client">Client</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Comment</label>
                    <input type="text" name="comment" id="editServiceComment">
                </div>
            </div>
            <div style="margin-top: 12px; display: flex; gap: 8px;">
                <button class="btn-primary" type="submit"><i class="fas fa-save"></i> Update Service</button>
            </div>
        </form>
    </div>
</div>

<script>
    (function () {
        const modal = document.getElementById('editClientModal');
        const closeBtn = document.getElementById('closeEditModal');
        const openButtons = document.querySelectorAll('.open-edit-modal');
        const serviceModal = document.getElementById('editServiceModal');
        const closeServiceBtn = document.getElementById('closeServiceEditModal');
        const serviceOpenButtons = document.querySelectorAll('.open-service-edit-modal');
        const addServiceModal = document.getElementById('addServiceModal');
        const closeAddServiceBtn = document.getElementById('closeAddServiceModal');
        const addServiceButtons = document.querySelectorAll('.open-add-service-modal');
        const serviceEntryContainer = document.getElementById('serviceEntryContainer');
        const addOtherServiceBtn = document.getElementById('addOtherServiceBtn');
        let serviceEntryIndex = 0;

        function openModal(data) {
            document.getElementById('editClientId').value = data.id || '';
            document.getElementById('editClientName').value = data.name || '';
            document.getElementById('editClientCompany').value = data.company || '';
            document.getElementById('editClientEmail').value = data.email || '';
            document.getElementById('editClientPhone').value = data.phone || '';
            document.getElementById('editClientRenewalDate').value = data.renewalDate || '';
            document.getElementById('editClientStatus').value = data.status || 'Active';
            modal.style.display = 'flex';
        }

        function closeModal() {
            modal.style.display = 'none';
        }

        openButtons.forEach((btn) => {
            btn.addEventListener('click', function () {
                openModal({
                    id: this.dataset.id,
                    name: this.dataset.name,
                    company: this.dataset.company,
                    email: this.dataset.email,
                    phone: this.dataset.phone,
                    renewalDate: this.dataset.renewalDate,
                    status: this.dataset.status
                });
            });
        });

        closeBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        function openServiceModal(data) {
            document.getElementById('editServiceId').value = data.id || '';
            document.getElementById('editServiceType').value = data.type || 'domain';
            document.getElementById('editServiceName').value = data.name || '';
            document.getElementById('editServiceRenewalDate').value = data.renewalDate || '';
            document.getElementById('editServiceAmount').value = data.amount || '';
            document.getElementById('editServiceComment').value = data.comment || '';
            document.getElementById('editServiceOwnershipType').value = data.ownershipType || 'client';
            serviceModal.style.display = 'flex';
        }

        function closeServiceModal() {
            serviceModal.style.display = 'none';
        }

        serviceOpenButtons.forEach((btn) => {
            btn.addEventListener('click', function () {
                openServiceModal({
                    id: this.dataset.id,
                    type: this.dataset.type,
                    name: this.dataset.name,
                    renewalDate: this.dataset.renewalDate,
                    amount: this.dataset.amount,
                    ownershipType: this.dataset.ownershipType
                });
            });
        });

        closeServiceBtn.addEventListener('click', closeServiceModal);
        serviceModal.addEventListener('click', function (e) {
            if (e.target === serviceModal) {
                closeServiceModal();
            }
        });

        function openAddServiceModal(data) {
            document.getElementById('addServiceClientId').value = data.clientId || '';
            document.getElementById('addServiceClientName').textContent = data.clientName || '';
            serviceEntryIndex = 0;
            serviceEntryContainer.innerHTML = '';
            appendServiceEntry();
            addServiceModal.style.display = 'flex';
        }

        function closeAddServiceModal() {
            addServiceModal.style.display = 'none';
        }

        function buildServiceEntry(index) {
            const wrapper = document.createElement('div');
            wrapper.className = 'service-block';
            wrapper.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <strong>Service ${index + 1}</strong>
                    <button type="button" class="icon-action-btn remove-service-entry" title="Remove Service"><i class="fas fa-trash-alt"></i></button>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Service Type</label>
                        <div style="display:flex; gap:14px; align-items:center; padding:10px 4px;">
                            <label style="margin:0; display:flex; gap:6px; align-items:center; font-weight:500;">
                                <input type="checkbox" name="services[${index}][types][]" value="domain" checked> Domain
                            </label>
                            <label style="margin:0; display:flex; gap:6px; align-items:center; font-weight:500;">
                                <input type="checkbox" name="services[${index}][types][]" value="hosting"> Hosting
                            </label>
                        </div>
                    </div>
                    <div class="form-group"><label>Name / Domain</label><input type="text" name="services[${index}][name]" required></div>
                    <div class="form-group"><label>Renewal Date</label><input type="date" name="services[${index}][renewal_date]"></div>
                    <div class="form-group"><label>Amount</label><input type="number" step="0.01" name="services[${index}][amount]"></div>
                    <div class="form-group">
                        <label>Ownership</label>
                        <select name="services[${index}][ownership_type]">
                            <option value="client">Client</option>
                            <option value="our">Our Side</option>
                        </select>
                    </div>
                </div>
            `;

            const removeBtn = wrapper.querySelector('.remove-service-entry');
            removeBtn.addEventListener('click', function () {
                if (serviceEntryContainer.children.length > 1) {
                    wrapper.remove();
                }
            });
            return wrapper;
        }

        function appendServiceEntry() {
            const entry = buildServiceEntry(serviceEntryIndex);
            serviceEntryContainer.appendChild(entry);
            serviceEntryIndex += 1;
        }

        addServiceButtons.forEach((btn) => {
            btn.addEventListener('click', function () {
                openAddServiceModal({
                    clientId: this.dataset.clientId,
                    clientName: this.dataset.clientName
                });
            });
        });

        closeAddServiceBtn.addEventListener('click', closeAddServiceModal);
        addOtherServiceBtn.addEventListener('click', appendServiceEntry);
        addServiceModal.addEventListener('click', function (e) {
            if (e.target === addServiceModal) {
                closeAddServiceModal();
            }
        });
    })();
</script>

<?php renderLayoutEnd(); ?>

