<?php
require 'db.php';

try {
    $pdo = db();
    
    // First drop existing tables to prevent "already exists" errors
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0;');
    $pdo->exec('DROP TABLE IF EXISTS admins, audit_logs, billings, clients, services;');
    $pdo->exec('SET FOREIGN_KEY_CHECKS=1;');
    
    // Load and execute the dump file
    $sql = file_get_contents(__DIR__ . '/u874184579_renewalswebapp.sql');
    if ($sql) {
        $pdo->exec($sql);
        echo "Successfully imported the SQL dump.\\n";
    } else {
        echo "Could not read SQL file.\\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\\n";
}
