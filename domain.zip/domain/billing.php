<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/layout.php';

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save_billing') {
        $id = (int) ($_POST['id'] ?? 0);
        $clientId = (int) ($_POST['client_id'] ?? 0);
        $serviceType = ($_POST['service_type'] ?? 'domain') === 'hosting' ? 'hosting' : 'domain';
        $serviceRef = trim((string) ($_POST['service_ref'] ?? ''));
        $renewalDate = trim((string) ($_POST['renewal_date'] ?? ''));
        $lastBillingDate = trim((string) ($_POST['last_billing_date'] ?? ''));
        $amount = (float) ($_POST['amount'] ?? 0);
        $status = ($_POST['status'] ?? 'Active') === 'Disabled' ? 'Disabled' : (($_POST['status'] ?? '') === 'Paid' ? 'Paid' : 'Active');

        if ($clientId > 0 && $serviceRef !== '' && $renewalDate !== '') {
            $checkClientStmt = $pdo->prepare('SELECT id FROM clients WHERE id = ? AND deleted_at IS NULL');
            $checkClientStmt->execute([$clientId]);
            $clientExists = (bool) $checkClientStmt->fetchColumn();
            if (!$clientExists) {
                header('Location: billing.php');
                exit;
            }

            if ($id > 0) {
                $stmt = $pdo->prepare(
                    'UPDATE billings
                     SET client_id = ?, service_type = ?, service_ref = ?, renewal_date = ?, last_billing_date = ?, amount = ?, status = ?
                     WHERE id = ? AND deleted_at IS NULL'
                );
                $stmt->execute([$clientId, $serviceType, $serviceRef, $renewalDate, $lastBillingDate ?: null, $amount, $status, $id]);
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO billings (client_id, service_type, service_ref, renewal_date, last_billing_date, amount, status)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([$clientId, $serviceType, $serviceRef, $renewalDate, $lastBillingDate ?: null, $amount, $status]);
            }
        }
    }

    header('Location: billing.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $pdo->prepare('UPDATE billings SET deleted_at = NOW() WHERE id = ? AND deleted_at IS NULL');
    $stmt->execute([$id]);
    header('Location: billing.php');
    exit;
}

if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    $stmt = $pdo->prepare("UPDATE billings SET status = CASE WHEN status = 'Active' THEN 'Disabled' ELSE 'Active' END WHERE id = ? AND deleted_at IS NULL");
    $stmt->execute([$id]);
    header('Location: billing.php');
    exit;
}

$editId = isset($_GET['edit']) ? (int) $_GET['edit'] : 0;
$editBilling = null;
if ($editId > 0) {
    $stmt = $pdo->prepare('SELECT * FROM billings WHERE id = ? AND deleted_at IS NULL');
    $stmt->execute([$editId]);
    $editBilling = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

$clients = $pdo->query('SELECT id, name FROM clients WHERE deleted_at IS NULL ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);
$services = $pdo->query('SELECT client_id, service_type, name FROM services WHERE deleted_at IS NULL ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);

$billPerPage = 10;
$billPage = max(1, (int) ($_GET['bill_page'] ?? 1));
$filterClientName = trim((string) ($_GET['filter_client_name'] ?? ''));
$filterServiceType = (string) ($_GET['filter_service_type'] ?? '');
$filterBillingMonth = trim((string) ($_GET['filter_billing_month'] ?? ''));
$filterRenewalMonth = trim((string) ($_GET['filter_renewal_month'] ?? ''));

if (!in_array($filterServiceType, ['', 'domain', 'hosting'], true)) {
    $filterServiceType = '';
}
if ($filterBillingMonth !== '' && !preg_match('/^\d{4}-\d{2}$/', $filterBillingMonth)) {
    $filterBillingMonth = '';
}
if ($filterRenewalMonth !== '' && !preg_match('/^\d{4}-\d{2}$/', $filterRenewalMonth)) {
    $filterRenewalMonth = '';
}

$billWhere = [
    'b.deleted_at IS NULL',
    'c.deleted_at IS NULL',
];
$billParams = [];

if ($filterClientName !== '') {
    $billWhere[] = 'c.name LIKE :client_name';
    $billParams[':client_name'] = '%' . $filterClientName . '%';
}
if ($filterServiceType !== '') {
    $billWhere[] = 'b.service_type = :service_type';
    $billParams[':service_type'] = $filterServiceType;
}
if ($filterBillingMonth !== '') {
    $billWhere[] = 'DATE_FORMAT(b.last_billing_date, "%Y-%m") = :billing_month';
    $billParams[':billing_month'] = $filterBillingMonth;
}
if ($filterRenewalMonth !== '') {
    $billWhere[] = 'DATE_FORMAT(b.renewal_date, "%Y-%m") = :renewal_month';
    $billParams[':renewal_month'] = $filterRenewalMonth;
}

$billWhereSql = implode(' AND ', $billWhere);

$billCountStmt = $pdo->prepare(
    "SELECT COUNT(*)
     FROM billings b
     JOIN clients c ON c.id = b.client_id
     WHERE {$billWhereSql}"
);
foreach ($billParams as $key => $value) {
    $billCountStmt->bindValue($key, $value);
}
$billCountStmt->execute();
$billTotal = (int) $billCountStmt->fetchColumn();

$billTotalPages = max(1, (int) ceil($billTotal / $billPerPage));
if ($billPage > $billTotalPages) {
    $billPage = $billTotalPages;
}
$billOffset = ($billPage - 1) * $billPerPage;

$billingStmt = $pdo->prepare(
    "SELECT b.*, c.name AS client_name
     FROM billings b
     JOIN clients c ON c.id = b.client_id
     WHERE {$billWhereSql}
     ORDER BY DATE(b.renewal_date) ASC, b.id DESC
     LIMIT :limit OFFSET :offset"
);
foreach ($billParams as $key => $value) {
    $billingStmt->bindValue($key, $value);
}
$billingStmt->bindValue(':limit', $billPerPage, PDO::PARAM_INT);
$billingStmt->bindValue(':offset', $billOffset, PDO::PARAM_INT);
$billingStmt->execute();
$billingRows = $billingStmt->fetchAll(PDO::FETCH_ASSOC);

renderLayoutStart('Billing Management', 'billing');
?>

<div class="card" style="margin-bottom: 20px;">
    <div class="row-head">
        <h3><i class="fas fa-file-invoice-dollar"></i> <?= $editBilling ? 'Edit Billing' : 'Add Renewal / Billing' ?></h3>
    </div>
    <form method="post">
        <input type="hidden" name="action" value="save_billing">
        <input type="hidden" name="id" value="<?= (int) ($editBilling['id'] ?? 0) ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Select Client *</label>
                <select name="client_id" required>
                    <option value="">-- Select Client --</option>
                    <?php foreach ($clients as $client): ?>
                        <option value="<?= (int) $client['id'] ?>" <?= ((int) ($editBilling['client_id'] ?? 0) === (int) $client['id']) ? 'selected' : '' ?>>
                            <?= esc($client['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Service Type *</label>
                <select name="service_type" required>
                    <option value="domain" <?= (($editBilling['service_type'] ?? '') === 'domain') ? 'selected' : '' ?>>Domain Renewal</option>
                    <option value="hosting" <?= (($editBilling['service_type'] ?? '') === 'hosting') ? 'selected' : '' ?>>Hosting Renewal</option>
                </select>
            </div>
            <div class="form-group">
                <label>Service Name *</label>
                <input list="service-list" name="service_ref" required value="<?= esc($editBilling['service_ref'] ?? '') ?>">
                <datalist id="service-list">
                    <?php foreach ($services as $service): ?>
                        <option value="<?= esc($service['name']) ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            </div>
            <div class="form-group"><label>Renewal Date *</label><input type="date" name="renewal_date" required value="<?= esc($editBilling['renewal_date'] ?? '') ?>"></div>
            <div class="form-group"><label>Last Billing Date</label><input type="date" name="last_billing_date" value="<?= esc($editBilling['last_billing_date'] ?? '') ?>"></div>
            <div class="form-group"><label>Amount</label><input type="number" step="0.01" name="amount" value="<?= esc(isset($editBilling['amount']) ? (string) $editBilling['amount'] : '') ?>"></div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="Active" <?= (($editBilling['status'] ?? 'Active') === 'Active') ? 'selected' : '' ?>>Active</option>
                    <option value="Paid" <?= (($editBilling['status'] ?? '') === 'Paid') ? 'selected' : '' ?>>Paid</option>
                    <option value="Disabled" <?= (($editBilling['status'] ?? '') === 'Disabled') ? 'selected' : '' ?>>Disabled</option>
                </select>
            </div>
        </div>
        <div style="margin-top: 12px; display: flex; gap: 8px;">
            <button class="btn-primary" type="submit"><i class="fas fa-save"></i> Save Billing</button>
            <a class="btn-secondary" href="billing.php">Clear</a>
        </div>
    </form>
</div>

<div class="card table-wrap">
    <div class="row-head">
        <h3><i class="fas fa-credit-card"></i> Billing List</h3>
    </div>
    <form method="get" style="margin-bottom:16px;">
        <div class="form-grid">
            <div class="form-group">
                <label>Client Name</label>
                <input type="text" name="filter_client_name" value="<?= esc($filterClientName) ?>" placeholder="Search by client">
            </div>
            <div class="form-group">
                <label>Service Based</label>
                <select name="filter_service_type">
                    <option value="">All Services</option>
                    <option value="domain" <?= $filterServiceType === 'domain' ? 'selected' : '' ?>>Domain</option>
                    <option value="hosting" <?= $filterServiceType === 'hosting' ? 'selected' : '' ?>>Hosting</option>
                </select>
            </div>
            <div class="form-group">
                <label>Billing (Month)</label>
                <input type="month" name="filter_billing_month" value="<?= esc($filterBillingMonth) ?>">
            </div>
            <div class="form-group">
                <label>Renewal (Month)</label>
                <input type="month" name="filter_renewal_month" value="<?= esc($filterRenewalMonth) ?>">
            </div>
        </div>
        <div style="margin-top: 10px; display:flex; gap:8px;">
            <button class="btn-primary" type="submit"><i class="fas fa-filter"></i> Apply Filter</button>
            <a class="btn-secondary" href="billing.php">Reset</a>
        </div>
    </form>
    <table class="data-table">
        <thead>
            <tr>
                <th>Client</th>
                <th>Type</th>
                <th>Service</th>
                <th>Renewal</th>
                <th>Last Bill</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$billingRows): ?>
                <tr><td colspan="8" class="inline-muted">No billing records found.</td></tr>
            <?php else: ?>
                <?php foreach ($billingRows as $row): ?>
                    <tr>
                        <td><?= esc($row['client_name']) ?></td>
                        <td><?= $row['service_type'] === 'domain' ? 'Domain' : 'Hosting' ?></td>
                        <td><?= esc($row['service_ref']) ?></td>
                        <td><?= esc($row['renewal_date']) ?></td>
                        <td><?= esc($row['last_billing_date']) ?></td>
                        <td><?= number_format((float) $row['amount'], 2) ?></td>
                        <td><span class="badge <?= $row['status'] === 'Active' ? 'badge-active' : 'badge-expiring' ?>"><?= esc($row['status']) ?></span></td>
                        <td>
                            <div class="action-links">
                                <a class="icon-action" title="Edit Billing" href="billing.php?edit=<?= (int) $row['id'] ?>">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <a class="icon-action icon-toggle" title="<?= $row['status'] === 'Active' ? 'Disable Billing' : 'Enable Billing' ?>" href="billing.php?toggle=<?= (int) $row['id'] ?>">
                                    <i class="fas <?= $row['status'] === 'Active' ? 'fa-toggle-off' : 'fa-toggle-on' ?>"></i>
                                </a>
                                <a class="icon-action icon-danger" title="Delete Billing" href="billing.php?delete=<?= (int) $row['id'] ?>" onclick="return confirm('Delete this billing record?');">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if ($billTotalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $billTotalPages; $i++): ?>
                <?php
                $billPageQuery = [
                    'bill_page' => $i,
                    'filter_client_name' => $filterClientName,
                    'filter_service_type' => $filterServiceType,
                    'filter_billing_month' => $filterBillingMonth,
                    'filter_renewal_month' => $filterRenewalMonth,
                ];
                $billPageLink = 'billing.php?' . http_build_query(array_filter($billPageQuery, static fn($v) => $v !== ''));
                ?>
                <?php if ($i === $billPage): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="<?= esc($billPageLink) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>

<?php renderLayoutEnd(); ?>
