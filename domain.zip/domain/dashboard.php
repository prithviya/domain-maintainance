<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/layout.php';

$pdo = db();

$totalClients = (int) $pdo->query('SELECT COUNT(*) FROM clients WHERE deleted_at IS NULL')->fetchColumn();
$totalDomains = (int) $pdo->query("SELECT COUNT(*) FROM services WHERE service_type = 'domain' AND deleted_at IS NULL")->fetchColumn();
$totalHosting = (int) $pdo->query("SELECT COUNT(*) FROM services WHERE service_type = 'hosting' AND deleted_at IS NULL")->fetchColumn();
$upcomingDomainRenewals = (int) $pdo->query("SELECT COUNT(*) FROM billings WHERE service_type = 'domain' AND deleted_at IS NULL AND DATE(renewal_date) > CURDATE()")->fetchColumn();
$upcomingHostingRenewals = (int) $pdo->query("SELECT COUNT(*) FROM billings WHERE service_type = 'hosting' AND deleted_at IS NULL AND DATE(renewal_date) > CURDATE()")->fetchColumn();
$upcomingRenewals = (int) $pdo->query(
    'SELECT COUNT(*) 
     FROM billings 
     WHERE deleted_at IS NULL
       AND DATE(renewal_date) >= CURDATE()
       AND DATE_FORMAT(renewal_date, "%Y-%m") = DATE_FORMAT(CURDATE(), "%Y-%m")'
)->fetchColumn();

$renewPerPage = 8;
$renewPage = max(1, (int) ($_GET['renew_page'] ?? 1));
$renewTotal = (int) $pdo->query(
    'SELECT COUNT(*)
     FROM billings b
     JOIN clients c ON c.id = b.client_id
     WHERE b.deleted_at IS NULL
       AND c.deleted_at IS NULL
       AND DATE(b.renewal_date) >= CURDATE()'
)->fetchColumn();
$renewTotalPages = max(1, (int) ceil($renewTotal / $renewPerPage));
if ($renewPage > $renewTotalPages) {
    $renewPage = $renewTotalPages;
}
$renewOffset = ($renewPage - 1) * $renewPerPage;

$upcomingStmt = $pdo->prepare(
    'SELECT b.renewal_date, b.service_type, b.service_ref, b.amount, c.name AS client_name
     FROM billings b
     JOIN clients c ON c.id = b.client_id
     WHERE b.deleted_at IS NULL
       AND c.deleted_at IS NULL
       AND DATE(b.renewal_date) >= CURDATE()
     ORDER BY DATE(b.renewal_date) ASC
     LIMIT :limit OFFSET :offset'
);
$upcomingStmt->bindValue(':limit', $renewPerPage, PDO::PARAM_INT);
$upcomingStmt->bindValue(':offset', $renewOffset, PDO::PARAM_INT);
$upcomingStmt->execute();
$upcomingRows = $upcomingStmt->fetchAll(PDO::FETCH_ASSOC);

renderLayoutStart('Dashboard', 'dashboard');
?>

<div class="stats-grid">
    <div class="stat-card"><div class="stat-number"><?= $totalClients ?></div><div class="stat-label"><i class="fas fa-users"></i> Total Clients</div></div>
    <div class="stat-card"><div class="stat-number"><?= $totalDomains ?></div><div class="stat-label"><i class="fas fa-globe"></i> Total Domains</div></div>
    <div class="stat-card"><div class="stat-number"><?= $totalHosting ?></div><div class="stat-label"><i class="fas fa-server"></i> Total Hosting</div></div>
    <div class="stat-card"><div class="stat-number"><?= $upcomingDomainRenewals ?></div><div class="stat-label">Upcoming Domain Renewals</div></div>
    <div class="stat-card"><div class="stat-number"><?= $upcomingHostingRenewals ?></div><div class="stat-label">Upcoming Hosting Renewals</div></div>
    <div class="stat-card"><div class="stat-number"><?= $upcomingRenewals ?></div><div class="stat-label">Total Upcoming Renewals</div></div>
</div>

<div class="card table-wrap">
    <div class="row-head">
        <h3><i class="fas fa-calendar-alt"></i> Upcoming Renewals</h3>
    </div>
    <table class="data-table">
        <thead>
            <tr>
                <th>Client</th>
                <th>Service Type</th>
                <th>Service Name</th>
                <th>Renewal Date</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!$upcomingRows): ?>
                <tr><td colspan="5" class="inline-muted">No upcoming renewals.</td></tr>
            <?php else: ?>
                <?php foreach ($upcomingRows as $row): ?>
                    <tr>
                        <td><?= esc($row['client_name']) ?></td>
                        <td><?= $row['service_type'] === 'domain' ? 'Domain' : 'Hosting' ?></td>
                        <td><?= esc($row['service_ref']) ?></td>
                        <td><?= esc($row['renewal_date']) ?></td>
                        <td>$<?= number_format((float) $row['amount'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if ($renewTotalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $renewTotalPages; $i++): ?>
                <?php if ($i === $renewPage): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="dashboard.php?renew_page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>

<?php renderLayoutEnd(); ?>
